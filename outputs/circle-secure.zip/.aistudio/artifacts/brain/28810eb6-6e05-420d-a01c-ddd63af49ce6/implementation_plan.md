# CIRCLE.iq — Master Product, Design & Development Blueprint

A unified, bilingual (Arabic RTL / English LTR) creative digital ecosystem connecting digital services, Iraqi freelance talent, and future community, academy, and event modules under one identity, database, and design language.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Please review and confirm the following architectural and scope decisions before we begin Phase 2 (building the Design System and Bilingual Homepage):
>
> 1. **AI Studio Live Runtime Stack vs. Target Export Stack**:
>    - **Confirmed Prototype Reference**: Preserving the uploaded geometric crimson `C` mark (`#d92735`) and mobile prototype proportions (`#0b0b0d`, `#ffffff`, `#ececec`, `#fdf1f2`).
>    - **Runtime Recommendation**: In this live workspace environment, we can build and run the full-stack bilingual Website, Admin Dashboard, and interactive Mobile Experience preview on **React + TypeScript + Tailwind CSS + Express**, backed by **Cloud SQL (PostgreSQL) + Firebase Auth** for real relational tables, RBAC, and Row-Level security—while keeping clean service/schema abstractions compatible with Next.js, Supabase, and Expo React Native deployment. Alternatively, let us know if you want the initial build to remain frontend-only before provisioning Cloud SQL PostgreSQL.
> 2. **Progressive Release Discipline (Zero Fake Data)**:
>    - **Phase 1 Live Modules**: Home, Digital Services & Request Workflow (`Submitted → Under Review → In Progress → Completed/Rejected`), Freelancer Discovery & Profiles, Auth/RBAC, and Admin Dashboard.
>    - **Gated Future Modules**: Community (`#community`), Academy, and Events will be modeled in the database and navigation architecture as explicitly labeled **Coming Soon / Future Module** previews—never presenting unfinished features, fake prices, fake reviews, or simulated ZainCash/MasterCard payments as active.
> 3. **Arabic Typography Selection**:
>    - Defaulting to **IBM Plex Sans Arabic** for Arabic RTL paired with **Plus Jakarta Sans** (body) and **Bricolage Grotesque** (display) for English LTR, plus **JetBrains Mono** for tabular request IDs and timestamps. (Switchable immediately if a brand book specifies DIN Arabic.)

---

## 1. Uploaded Brand & Reference Asset Analysis

Inspection of the uploaded CIRCLE brand mark and mobile HTML prototype establishes the non-negotiable visual grammar:

- **Official Brand Mark**: Sharp, angular crimson-red geometric `C` emblem (`#d92735`) with faceted polygon cutouts. The mark must be embedded directly in its original geometry without distortion, recoloring, or replacement.
- **Slogan & Concept**: *"Your Work Deserves to Be Seen."* / *"Everything connects."* (*"كل شيء يترابط — الخدمات. المواهب. المجتمع."*)
- **Reference Color Hierarchy**:
  - Primary Crimson Accent: `#d92735` (hover `#b81f2b`, soft surface tint `#fdf1f2` / `#fdeaec`)
  - Secondary Deep Black: `#0b0b0d` (charcoal surface `#1b1b1f`)
  - Canvas & Card Surfaces: Crisp `#ffffff` on subtle `#f4f4f5` canvas with `#ececec` hairline borders
  - Muted Secondary Text: `#5f6168` / `#6b6d74`
- **Reference Visual Motifs**:
  - Faceted crimson polygon accent crops on dark hero/cover banners (`clip-path` geometric shards echoing the `C` logo).
  - Clean rounded cards (`16px–20px` radius) with hairline borders rather than heavy shadows.
  - Freelancer portfolio previews featuring 3-swatch/tile visual grids, skill summaries, and verified checkmarks.
  - Mobile thumb-zone ergonomics: 4-tab bottom navigation bar (`الرئيسية`, `الخدمات`, `المستقلون`, `الملف الشخصي`) with soft crimson active pill indicator (`rgba(217, 39, 53, 0.1)`).

---

## 2. Complete Product Architecture

All three connected products—the **Responsive Website**, **Mobile Application**, and **Admin Dashboard**—share a single unified backend API, identity provider, RBAC permission layer, relational PostgreSQL database, and object storage bucket.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       CIRCLE.iq CLIENT ECOSYSTEM                        │
├─────────────────────────┬───────────────────────┬───────────────────────┤
│   A. CIRCLE Website     │  B. CIRCLE Mobile App │  C. Admin Dashboard   │
│   (Desktop / Tablet /   │  (iOS & Android       │  (Protected RBAC      │
│    Mobile Web, EN/AR)   │   Touch-First, AR/EN) │   Operations Console) │
└────────────┬────────────┴───────────┬───────────┴───────────┬───────────┘
             │                        │                       │
             └────────────────────────┼───────────────────────┘
                                      ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    UNIFIED API & SECURITY GATEWAY                       │
│  • Input Validation   • Rate Limiting   • RBAC Guard   • Audit Logger   │
│  • Bilingual i18n Middleware (AR RTL / EN LTR)                          │
└────────────┬────────────────────────┬───────────────────────┬───────────┘
             │                        │                       │
             ▼                        ▼                       ▼
┌─────────────────────┐  ┌────────────────────────┐  ┌────────────────────┐
│  Identity & Auth    │  │  PostgreSQL Database   │  │   Object Storage   │
│  • Multi-role JWT   │  │  • Relational Schema   │  │  • Portfolio Media │
│  • Session Control  │  │  • Row Level Security  │  │  • CVs & Request   │
│  • Email Verify     │  │  • Audit & Moderation  │  │    Attachments     │
└─────────────────────┘  └────────────────────────┘  └────────────────────┘
```

### Shared Core Layers
1. **Identity & Multi-Role RBAC**: One account per person supporting multiple concurrent roles (`visitor`, `user`, `freelancer`, `service_provider`, `admin`, `super_admin`). Role checks are enforced server-side and at the database RLS layer.
2. **Modular Domain Services**: Separated cleanly from UI views—Services & Requests Engine, Freelancer Directory & Portfolio Engine, Notification & Audit Engine, Moderation & Reporting Engine, and gated future hooks for Community, Academy, and Events.
3. **Payment Readiness Layer**: Abstracted payment adapter interface prepared for future **ZainCash** and **MasterCard** merchant verification without storing card numbers or simulating transactions.

---

## 3. Full Website Sitemap (17 Pages)

Every website route adapts across Desktop (`1440px`), Laptop, Tablet, and Mobile viewports with seamless English (LTR) / Arabic (RTL) switching:

| # | Route | Page | Release Scope | Primary Capabilities |
| :- | :--- | :--- | :--- | :--- |
| 1 | `/` | **Home** | Phase 1 (Live) | Hero (*"Everything connects."* / *"كل شيء يترابط."*), official logo, primary CTAs, platform overview, 6 service categories, featured freelancer portfolios, future module roadmap preview, footer |
| 2 | `/services` | **Services** | Phase 1 (Live) | Category filter, live search, 6 core service pillars (Website Dev, E-Commerce, Mobile Apps, UI/UX, Visual Identity, Digital Solutions) |
| 3 | `/services/:slug` | **Service Details** | Phase 1 (Live) | Scope, deliverables, requirements checklist, and interactive **Request Service** form with file attachments |
| 4 | `/freelancers` | **Freelancers** | Phase 1 (Live) | Talent discovery directory, search, category/skill filters, verified badges, 3-tile work previews |
| 5 | `/freelancers/:username` | **Freelancer Profile** | Phase 1 (Live) | Bio, skills, portfolio gallery, CV download, external links, visibility status (no internal payments/chat) |
| 6 | `/community` | **Community** | Future Module | Gated preview banner explaining upcoming text posts, polls, and moderation; clearly disabled until approved |
| 7 | `/profile` | **User Profile** | Phase 1 (Live) | Cover banner, avatar, bio, role indicators, Portfolio / CV / Requests tabs, external links |
| 8 | `/login` | **Login** | Phase 1 (Live) | Email/password sign-in, session persistence, redirect back to requested flow |
| 9 | `/register` | **Registration** | Phase 1 (Live) | Account creation, role intent selection (Client / Freelancer), email verification trigger |
| 10 | `/forgot-password` | **Forgot Password** | Phase 1 (Live) | Password recovery request and reset confirmation flow |
| 11 | `/settings` | **User Settings** | Phase 1 (Live) | Profile editing, language preference (AR/EN), profile visibility, active sessions, password update |
| 12 | `/notifications` | **Notifications** | Phase 1 (Live) | Service request status updates, verification notices, system alerts with mark-read controls |
| 13 | `/search` | **Search Results** | Phase 1 (Live) | Unified search across services, service categories, and public freelancer profiles |
| 14 | `/about` | **About CIRCLE** | Phase 1 (Live) | Mission in Iraq, progressive 4-pillar ecosystem vision, brand story |
| 15 | `/contact` | **Contact** | Phase 1 (Live) | Validated inquiry form for partnerships, enterprise service inquiries, and support |
| 16 | `/privacy` | **Privacy Policy** | Phase 1 (Live) | Bilingual data handling, file attachment retention, and user privacy rights |
| 17 | `/terms` | **Terms of Service** | Phase 1 (Live) | Platform rules, service request terms, external freelancer transaction disclaimer |

---

## 4. Mobile Application Sitemap (iOS & Android)

Preserving the exact 4-tab layout and card proportions from the uploaded mobile reference (`index_4c103509.html`), with all touch targets $\ge 44\times44\text{px}$ and sticky bars $\le 15\%$ of viewport height:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    CIRCLE MOBILE BOTTOM TAB BAR                         │
├──────────────────┬──────────────────┬──────────────────┬────────────────┤
│ 1. الرئيسية      │ 2. الخدمات       │ 3. المستقلون    │ 4. الملف الشخصي│
│    (Home)        │    (Services)    │    (Freelancers) │    (Profile)   │
└────────┬─────────┴────────┬─────────┴────────┬─────────┴───────┬────────┘
         │                  │                  │                 │
         ▼                  ▼                  ▼                 ▼
  • Search Bar       • Category Filter  • Talent Search   • Cover & Avatar
  • Notifications    • Service Cards    • Skill Filters   • Bio & Roles
  • Welcome Header   • Service Detail   • Portfolio Tiles • Portfolio / CV
  • Featured Svcs    • Request Form +   • Freelancer      • Social Links
  • Talent Spotlight   File Attachments   Profile Page    • Account &
  • Announcements                       • External Links    Privacy Settings
                                                          • Logout
```

Additional Mobile Stack Screens (Push / Modal Sheets):
- **Auth Stack**: Login, Registration, Forgot Password
- **Notifications Sheet**: Request status transitions & system alerts
- **Service Request Bottom Sheet**: Structured requirements form + document/image attachment picker + request tracking timeline (`Submitted → Under Review → In Progress → Completed / Rejected`)

---

## 5. Admin Dashboard Sitemap (12 Protected Sections)

Accessible strictly to `admin` and `super_admin` roles via server-enforced RBAC guards and audit-logged mutations:

1. **Overview**: Real-time counts of registered users, active freelancers, pending service requests, and open moderation reports (only real database counts—zero fabricated metrics).
2. **User Management**: Search users, inspect roles, verify accounts, suspend/unsuspend accounts with audit reason.
3. **Freelancer Management**: Review freelancer applications, verify identities, toggle directory visibility.
4. **Service Management**: Create, edit, organize, and enable/disable the 6 service categories and service listings.
5. **Service Requests**: Triage incoming client requests, inspect attachments, advance workflow status (`Submitted → Under Review → In Progress → Completed / Rejected`), and add internal review notes.
6. **Content Management**: Manage homepage announcements, featured selections, and future-module visibility flags (Community, Academy, Events).
7. **Reports**: Review user-submitted content/profile reports.
8. **Moderation**: Execute warn, hide, or suspend actions linked to report records.
9. **Notifications**: Broadcast platform-wide or role-targeted notifications.
10. **Roles & Permissions**: Assign/revoke granular role permissions (`super_admin` gated).
11. **System Settings**: Bilingual platform configuration, file upload limits, feature flags.
12. **Activity Logs**: Immutable chronological audit trail of administrative and security events.

---

## 6. Design System

### Aesthetic & Spatial Rules
- **60-30-10 Palette Allocation**:
  - **60% Neutral Canvas**: `#ffffff` primary surfaces and `#f4f4f5` secondary canvas.
  - **30% Structural Surfaces**: `#0b0b0d` deep black contrast blocks, `#1b1b1f` charcoal banners, `#ececec` 1px hairline borders, `#5f6168` muted labels.
  - **10% Accent Budget**: `#d92735` CIRCLE Crimson Red reserved strictly for primary CTAs, active navigation indicators, verified marks, and focus rings (`#b81f2b` hover, `#fdf1f2` soft alert/promo surface).
- **Typography Pairing (`2+1` Rule)**:
  - **Arabic (RTL)**: `IBM Plex Sans Arabic` (400, 500, 600, 700) with crisp RTL alignment and mirrored directional icons.
  - **English (LTR)**: `Bricolage Grotesque` (600–700 display headlines, `text-wrap: balance`) paired with `Plus Jakarta Sans` (400–600 body copy).
  - **Data & Request IDs**: `JetBrains Mono` with `font-variant-numeric: tabular-nums`.
- **Anti-Slop & Restraint Standards**:
  - **Zero Static Pill Clutter**: Metadata (`Baghdad · Visual Identity · 2026`) renders as clean unboxed typography with `·` separators; interactive filter tabs use clean `<button>` segmented controls.
  - **Single-Elevation Depth**: Flat hairline borders (`1px solid #ececec`) instead of stacked drop shadows or nested cards within cards.
  - **Top Bar Contract**: Single-row 3-zone desktop header (`CIRCLE.IQ` logo mark + 4–5 concise single-line nav links + Language toggle & Account CTA).
  - **Complete UI States**: Every view ships with matching skeleton loading states, actionable empty states, inline validation errors, and accessible `focus-visible` crimson rings.

### Reusable Component Library
- **Navigation**: Responsive Top Header, Bilingual Language Switcher (`EN | العربية`), Mobile Bottom Tab Bar, Admin Sidebar.
- **Primitives**: Primary/Ghost/Danger Buttons (`min-h-[44px]`), Validated Form Inputs & Textareas, File Upload Dropzone, Search Input, Segmented Filter Tabs, Modals & Bottom Sheets.
- **Domain Modules**: Service Category Card, Service Request Timeline Tracker, Freelancer Showcase Card (with 3-tile preview), Profile Cover & Tab Bar, Notification Row, Audit Log Row, Future-Module Gate Banner.

---

## 7. Database Architecture (PostgreSQL + Row Level Security)

Relational schema designed for multi-role RBAC, progressive modules, and strict RLS enforcement:

```
┌──────────────┐       ┌────────────────┐       ┌──────────────────┐
│    users     │1─────1│    profiles    │       │      roles       │
└──────┬───────┘       └────────────────┘       └────────┬─────────┘
       │                                                 │
       ├───────< user_roles >────────────────────────────┤
       │                                                 ▼
       │                                        ┌──────────────────┐
       │                                        │ role_permissions │
       │                                        └──────────────────┘
       │
       ├───────1 freelancer_profiles ───< portfolio_projects
       │                 │
       │                 └───< freelancer_skills >─── skills
       │
       ├───────< service_requests >─── services >─── service_categories
       │                 │
       │                 └───< request_attachments
       │
       ├───────< notifications
       ├───────< reports ───< moderation_actions
       └───────< audit_logs
```

### Core Tables & Constraints
1. **`users`**: `id (uuid PK)`, `email (unique)`, `password_hash / auth_uid`, `status ('active' | 'suspended' | 'pending')`, `email_verified_at`, `created_at`.
2. **`profiles`**: `user_id (PK/FK)`, `display_name_en`, `display_name_ar`, `username (unique)`, `avatar_url`, `cover_url`, `bio_en`, `bio_ar`, `city`, `preferred_locale ('ar' | 'en')`, `is_public (bool)`.
3. **`roles` & `permissions` & `user_roles` & `role_permissions`**: Normalized RBAC tables supporting multi-role assignment per user (`visitor`, `user`, `freelancer`, `service_provider`, `admin`, `super_admin`) with composite primary keys and cascade deletes.
4. **`service_categories`**: `id`, `slug (unique)`, `title_en`, `title_ar`, `description_en`, `description_ar`, `accent_hex`, `sort_order`, `is_active`.
5. **`services`**: `id`, `category_id (FK)`, `slug (unique)`, `title_en`, `title_ar`, `summary_en`, `summary_ar`, `requirements_schema (jsonb)`, `is_active`.
6. **`service_requests`**: `id`, `reference_code (unique)`, `requester_id (FK users)`, `service_id (FK services)`, `project_title`, `requirements_brief`, `budget_note`, `status ('submitted' | 'under_review' | 'in_progress' | 'completed' | 'rejected')`, `admin_notes`, `created_at`, `updated_at`. Indexed on `(requester_id, status)` and `(created_at DESC)`.
7. **`request_attachments`**: `id`, `request_id (FK)`, `file_name`, `mime_type`, `byte_size`, `storage_path`, `uploaded_by (FK)`. Enforces server-side MIME/size limits.
8. **`freelancer_profiles`**: `user_id (PK/FK)`, `headline_en`, `headline_ar`, `is_verified (bool)`, `visibility ('public' | 'hidden')`, `cv_storage_path`, `external_links (jsonb)`.
9. **`portfolio_projects`**: `id`, `freelancer_id (FK)`, `title_en`, `title_ar`, `description_en`, `description_ar`, `media_urls (jsonb)`, `external_url`, `sort_order`.
10. **`skills` & `freelancer_skills`**: Normalized bilingual skill tags (`name_en`, `name_ar`, `slug`) with GIN/B-tree search indexes.
11. **`notifications`**: `id`, `user_id (FK)`, `type`, `title_en`, `title_ar`, `body_en`, `body_ar`, `link_path`, `read_at`, `created_at`.
12. **`reports` & `moderation_actions`**: `reporter_id`, `target_type`, `target_id`, `reason`, `status`, `moderator_id`, `action_taken`, `notes`, `created_at`.
13. **`audit_logs`**: `id`, `actor_id (FK)`, `action`, `entity_type`, `entity_id`, `metadata (jsonb)`, `ip_address`, `created_at`. Append-only for admin/system actions.
14. **Future-Ready Reserved Tables** *(disabled by feature flag until Phase 10+)*: `community_posts`, `community_polls`, `academy_courses`, `events`.

### Row Level Security (RLS) Strategy
- Public read allowed only on active `service_categories`, active `services`, and `freelancer_profiles` where `visibility = 'public'` and user `status = 'active'`.
- `service_requests` & `request_attachments`: Readable/creatable only by `requester_id = current_user_id` or users holding `admin` / `super_admin` permissions.
- `audit_logs`, `reports`, `moderation_actions`, and `role_permissions`: Strictly restricted to authenticated admins; standard users can insert `reports` for content moderation without viewing other users' reports.

---

## 8. Development Milestones (Phases 1–10)

| Phase | Milestone | Key Deliverables |
| :- | :--- | :--- |
| **Phase 1** | Architecture & Blueprint *(Current)* | Brand asset analysis, sitemaps, design system, DB schema, dependency audit |
| **Phase 2** | Design System & Homepage | Brand tokens (`#d92735` / `#0b0b0d`), bilingual RTL/LTR engine, shared UI primitives, Homepage + official logo integration |
| **Phase 3** | Database & Backend Foundations | Relational PostgreSQL schema, RLS policies, validation schemas, API gateway & audit logging |
| **Phase 4** | Responsive Website Pages | All public pages (Services, Service Details, Freelancers, Search, About, Contact, Legal, Future Community Gate) |
| **Phase 5** | Auth & User Profiles | Registration, Login, Forgot Password, Session Management, User Profile & Account Settings |
| **Phase 6** | Services & Freelancer Workflows | Live service request submission with attachments, status tracking, freelancer portfolio & CV manager |
| **Phase 7** | Admin Dashboard | Protected 12-module admin console (Users, Freelancers, Services, Requests triage, Moderation, Audit Logs) |
| **Phase 8** | Security & QA Hardening | RBAC penetration checks, upload validation, rate limiting, accessibility & RTL visual audit |
| **Phase 9** | Mobile App (Expo / React Native) | Native iOS & Android app matching the 4-tab mobile prototype and sharing the unified backend |
| **Phase 10** | Beta & Production Launch | Deployment, monitoring, App Store / Play Store assets, future ZainCash/MasterCard & Community readiness |

---

## 9. External Dependencies & Estimated Costs

| Category | Service / Dependency | Purpose | Estimated Monthly Cost |
| :--- | :--- | :--- | :--- |
| **Web Hosting** | Vercel / Cloud Run | Bilingual SSR/SPA website hosting & CDN | $0 (Free/Hobby) → $20/mo Pro |
| **Database & Auth** | PostgreSQL (Cloud SQL / Supabase) | Relational DB, RLS, Auth, Object Storage | $0 Free Tier → $15–$25/mo Starter |
| **Transactional Email** | Resend / Postmark | Email verification, password resets, request alerts | $0 (up to 3k emails/mo) → $20/mo |
| **Error Monitoring** | Sentry | Runtime exception & API latency tracking | $0 Developer Tier → $26/mo |
| **Mobile Builds & Stores** | Expo EAS + Apple Developer + Google Play | iOS & Android builds and store publishing | $99/yr (Apple) + $25 one-time (Google) + $0–$19/mo EAS |
| **Domain & DNS** | `.iq` domain + Cloudflare DNS/WAF | `circle.iq` domain registration, SSL, rate limiting | ~$50–$120/yr `.iq` domain; $0 Cloudflare Free |
| **Future Iraq Payments** | ZainCash Business / MasterCard Gateway | Approved local payment processing (post-Phase 10) | Merchant KYB onboarding + per-transaction gateway fee |

---

## Next Step After Approval

Once you approve this blueprint (**Proceed**), we will begin **Phase 2**: implementing the unified **CIRCLE.iq Design System** (preserving the exact geometric crimson logo, `#d92735` / `#0b0b0d` palette, and bilingual EN LTR / AR RTL typography) and building the complete responsive **CIRCLE.iq Homepage** alongside the core navigation shell.
